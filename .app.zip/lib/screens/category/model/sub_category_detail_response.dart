class SubCategoryDetailResponse {
  SubCategoryDetailResponse();

  factory SubCategoryDetailResponse.fromJson(Map<String, dynamic> json) {
    return SubCategoryDetailResponse();
  }
}
