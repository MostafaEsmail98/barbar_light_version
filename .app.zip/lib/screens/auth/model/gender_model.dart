import 'package:flutter/material.dart';

class GenderModel {
  String? name;
  IconData? icon;
  String? value;

  GenderModel({this.name, this.icon, this.value});
}
